<!-- Ian Dozier -->
<?php require('includes/header.php'); ?>
<section id="Academics" class="content-section">
        <div class="text-box">
            <h2>Academics</h2>
            <hr>
            <div align="justify">
            <p>
                I'm currently majoring in computer science with a concentration in cybersecurity, while also minoring in French.
                I'm currently on track to graduate in May 2025 with a 3.3 gpa. During my time at UNCW I met a lot of amazing students and
                faculty members. I was able to program a to-do list with my classmates, and I even made a game called MineSweeper. I've learned the
                different data structures, object-oriented programming techniques and all the way up to the complexities of algorithms. In addition to
                how CPUs run and behave, and how a computer makes network calls with its own unique address, or an ip address.

            </p>
        </div>
        </div>
    </section>
<?php include('includes/footer.php'); ?>