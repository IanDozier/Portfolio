<!DOCTYPE html>
<!-- Ian Dozier -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/main.css">
    <script src="styles/script.js" defer></script>
    <title>Ian Dozier's Portfolio</title>
</head>
<body>
<div class="background">
  <!-- Just for the background -->
</div>
<main>
<div class="profile-section">
    <button onclick="openLink('https://www.linkedin.com/in/ian-dozier-582b89260/')">
      <img src="styles/Profile photo.jpeg" alt="profile photo" class="profile-pic">
    </button>
</div>
<div class="text-box">
        <h1> Welcome to My Portfolio </h1>
        <p class="by-line">By: Ian Dozier</p>
        <hr>
  </div>
<?php if (isset($_GET['send']) && $_GET['send'] == "Send") {

	if (!empty($_GET['name']))
		$name = $_GET['name'];
	else
		$missing['name'] = "Name is required";


  if (!empty($_GET['password']))
		$password = $_GET['password'];
	else
		$missing['password'] = "A password is required";

  if (!empty($_GET['re_try_password']))
		$repass = $_GET['re_try_password'];
	else
		$missing['re_try_password'] = "Please confirm your password";

  $compare = false;
  
  if (!empty($password) && !empty($repass) && strcmp($password, $repass) != 0){

    $password = null;
    $repass = null;
    $missing['password'] = "Passwords didn't match";
    $missing['re_try_password'] = "Try again";
  }
  else{
    $compare = true;
  }

  if(empty($missing) && $compare){
    
    header("Location: index.php");
    return $name;
    exit;
  }

  


}
?>
<form method="get" action="info.php">
    <fieldset>
        <legend>Tell me about yourself and register to stay updated</legend>
        <p><label>Name<br>
        <?php if(isset($missing['name'])) echo '<p class = "warning">' .$missing['name']. '</p>';?>
        <input type="text" name="name" id="Name"
        <?php if(isset($name)) echo 'value = "'. htmlspecialchars($name). '"';?>>
        </label></p>

        <p><label>Company<br>
        <input type="text" name="company" id="Company">
        </label></p>

        <p><label>Email<br>
        <input type="text" name="email" id="Email">
        </label></p>

        <p><label>Password<br>
        <?php if(isset($missing['password'])) echo '<p class = "warning">' .$missing['password']. '</p>';?>
        <input type="password" name="password" id="Password"
        <?php if(isset($password)) echo 'value = "'. htmlspecialchars($password). '"';?>>
        </label></p>

        <p><label>Re-try Password<br>
        <?php if(isset($missing['re_try_password'])) echo '<p class = "warning">' .$missing['re_try_password']. '</p>';?>
        <input type="password" name="re_try_password" id="PasswordRedo"
        <?php if(isset($repass)) echo 'value = "'. htmlspecialchars($repass). '"';?>>
        </label></p>

    </fieldset>
    <p><input type="submit" name="send"value="Send"></p>   
</form>
<?php include('includes/footer.php'); ?>