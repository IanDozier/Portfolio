function openLink(url){
    window.open(url, '_blank');
}