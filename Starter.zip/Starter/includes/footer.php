<!-- Ian Dozier -->
</main>
    <footer>
        <p>&copy; 2024 Ian Dozier</p>
        <p><a href="contact_me.php">Contact Me</a></p>
        <p><a href="https://www.linkedin.com/in/ian-dozier-582b89260/">LinkedIn</a></p>
    </footer>
</body>
</html>