<!-- Ian Dozier -->
<?php require('includes/header.php'); ?>
<section id="Contact Me" class="content-section">
        <div class="text-box">
            <h2>Contact Me</h2>
            <hr>
        </div>
        <br>
        <br>
        <br>
            <div class="row" align="left">
                <div class="logo">
                    <button onclick="openLink('https://www.linkedin.com/in/ian-dozier-582b89260/')">
                    <img src="styles/linkedin-logo.png" alt="linkedin" class="logo">
                    </button>
                </div>
        </div>
        <p>
        Find me on LinkedIn or send me an email. <b>Try clicking the buttons</b>
        </p>
</section>
<?php include('includes/footer.php'); ?>